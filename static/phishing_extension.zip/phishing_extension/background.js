chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Trigger only when the page starts loading and has a valid URL
  if (changeInfo.status === "loading" && tab.url && tab.active) {
    const url = tab.url;

    // Send the URL to the backend for phishing prediction
    fetch("http://127.0.0.1:5000/predict", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      credentials: "include",  // Important if using sessions
      body: JSON.stringify({ url })
    })
    .then(response => {
      if (!response.ok) {
        throw new Error("Non-200 response");
      }
      return response.json();
    })
    .then(data => {
      // If backend says it's a phishing site, redirect to blocked page
      if (data.status === "phish" || data.status === "already_blocked") {
        console.log("🚫 Phishing URL detected, redirecting to blocked.html");

        chrome.tabs.update(tabId, {
          url: chrome.runtime.getURL("blocked.html") + "?url=" + encodeURIComponent(url)
        });
      }
    })
    .catch(error => {
      console.error("❌ Error during phishing check:", error);
    });
  }
});
