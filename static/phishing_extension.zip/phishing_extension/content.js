chrome.webRequest.onBeforeRequest.addListener(
  async function (details) {
    const url = details.url;
    const response = await fetch("https://yourdomain.com/check_url", {
      method: "POST",
      body: JSON.stringify({ url }),
      headers: { "Content-Type": "application/json" }
    });

    const result = await response.text();
    if (result === "blocked") {
      return { redirectUrl: "https://yourdomain.com/block?url=" + encodeURIComponent(url) };
    }
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);
