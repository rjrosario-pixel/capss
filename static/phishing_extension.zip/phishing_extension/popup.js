document.addEventListener('DOMContentLoaded', () => {
  const currentUrlDiv = document.getElementById("current-url");
  const scanBtn = document.getElementById("scan-btn");
  const resultText = document.getElementById("result");
  const blockBtn = document.getElementById("block-btn");
  const loginReminder = document.getElementById("loginReminder");

  // Reset UI
  resultText.textContent = "";
  blockBtn.style.display = "none";
  loginReminder.style.display = "none";

  // Get current tab URL and display
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0 && tabs[0].url) {
      const url = tabs[0].url;
      currentUrlDiv.textContent = `🔗 ${url}`;
    } else {
      currentUrlDiv.textContent = "❌ No active URL found.";
    }
  });

  // Handle scan button click
  scanBtn.addEventListener("click", () => {
    resultText.textContent = "🔍 Scanning...";
    blockBtn.style.display = "none";
    loginReminder.style.display = "none";

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || tabs.length === 0) {
        resultText.textContent = "❌ No active tab found.";
        return;
      }

      const url = tabs[0].url;

      fetch("http://127.0.0.1:5000/predict", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        credentials: "include",
        body: JSON.stringify({ url })
      })
        .then(async (res) => {
          const contentType = res.headers.get("content-type") || "";

          if (res.status === 401) {
            loginReminder.style.display = "block";
            resultText.textContent = "🔒 Please log in to scan.";
            throw new Error("User not logged in");
          }

          if (!contentType.includes("application/json")) {
            const text = await res.text();
            throw new Error("Invalid response: " + text.slice(0, 100));
          }

          return res.json();
        })
        .then((data) => {
          console.log("Scan result:", data);

          if (data.result === "Phish") {
            resultText.textContent = "⚠️ ALERT: This site is phishing!";
            blockBtn.style.display = "inline-block";
          } else if (data.result === "Safe") {
            resultText.textContent = "✅ This site is safe.";
          } else {
            resultText.textContent = "❓ Unknown result.";
          }
        })
        .catch((err) => {
          console.error("Scan error:", err);
          if (!resultText.textContent.includes("Please log in")) {
            resultText.textContent = "❌ Scan failed. " + err.message;
          }
        });
    });
  });

  // Handle block button click
  blockBtn.addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || tabs.length === 0) {
        resultText.textContent = "❌ No active tab found.";
        return;
      }

      const url = tabs[0].url;

      fetch("http://127.0.0.1:5000/block_url", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        credentials: "include",
        body: JSON.stringify({ url })
      })
        .then((response) => {
          if (response.status === 401) {
            loginReminder.style.display = "block";
            resultText.textContent = "🔒 Please log in to block URLs.";
            return;
          }

          if (response.ok) {
            resultText.textContent = "🚫 Site has been blocked!";
            blockBtn.style.display = "none";

            // Reload tab for background to intercept
            chrome.tabs.update(tabs[0].id, { url: url });
          } else {
            resultText.textContent = "⚠️ Failed to block site.";
          }
        })
        .catch((error) => {
          console.error("Block error:", error);
          resultText.textContent = "❌ Error blocking site.";
        });
    });
  });
});
